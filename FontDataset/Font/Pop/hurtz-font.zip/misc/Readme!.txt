thankyou for downloading.
this font is for Personal use.
dont use it for any commercial project.

link for buy : https://fontbundles.net/crumphand/1240354-hurtz
thank you, Regards!