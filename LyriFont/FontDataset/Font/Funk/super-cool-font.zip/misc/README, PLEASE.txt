This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://singlelinestd.com/product/super-cool/

Super Cool is a quirky, groovy, fun, and cool display font. The font features thick, rounded letters with a playful twist. The letters are slightly uneven, giving the font a unique and handcrafted look.

For questions, please visit https://singlelinestd.com/contact/