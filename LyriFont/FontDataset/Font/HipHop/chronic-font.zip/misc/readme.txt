
Chronic
by Johan Waldenstr�m 2019

This is a freeware hiphop graffiti-inspired decorative font.
The font only has lower case characters, so make sure capslock isn�t on when using it.
Feel free to distribute this font, or any other one of my fonts. Do not sell them though.
See all of my fonts at www.11-D.net

---

How to install:

Unzip the font into the fonts directory, located at c:\windows\fonts\

---

Have fun!